# Contributing to Daily AI News Podcast Generator

Thank you for considering contributing to this project! 🎉

## How to Contribute

### Reporting Bugs
- Use GitHub Issues
- Include n8n version, node versions, error logs
- Describe expected vs actual behavior

### Suggesting Features
- Open an issue with "Feature Request" label
- Describe the use case
- Explain why it would be useful

### Code Contributions

1. **Fork the repository**
2. **Create a feature branch**
   ```bash
   git checkout -b feature/your-feature-name
   ```
3. **Make your changes**
   - Test thoroughly
   - Update README if needed
4. **Commit with clear message**
   ```bash
   git commit -m "feat: add X feature"
   ```
5. **Push and create PR**

### Areas for Contribution

We especially welcome contributions in:

- **New News Sources**: Add more AI news websites
- **Language Support**: Translations, multi-language podcasts
- **Alternative TTS**: Support for other TTS providers
- **Enhanced Deduplication**: Better duplicate detection
- **Cost Optimization**: Reduce API costs
- **Error Handling**: More robust error recovery
- **Testing**: Automated tests for key functions
- **Documentation**: Improve guides, add tutorials

### Coding Standards

- Use clear, descriptive variable names
- Add comments for complex logic
- Follow existing code style
- Test before submitting PR

### Commit Message Format

Use conventional commits:
- `feat:` New feature
- `fix:` Bug fix
- `docs:` Documentation only
- `refactor:` Code refactoring
- `test:` Adding tests
- `chore:` Maintenance

Example: `feat: add support for RSS feeds from Medium`

## Development Setup

1. Fork and clone repository
2. Import workflow to n8n
3. Set up test credentials (use test API keys)
4. Make changes
5. Test thoroughly
6. Submit PR

## Questions?

Open an issue or discussion on GitHub!

Thank you for contributing! 🙏
